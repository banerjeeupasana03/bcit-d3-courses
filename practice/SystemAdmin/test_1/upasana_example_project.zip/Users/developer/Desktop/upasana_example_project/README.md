### upasana_example_project
This is a sample project which contains some html and css

#### Deployment
This project is deployed on heroku

https://dashboard.heroku.com/apps/upasana-example-project/deploy/github
