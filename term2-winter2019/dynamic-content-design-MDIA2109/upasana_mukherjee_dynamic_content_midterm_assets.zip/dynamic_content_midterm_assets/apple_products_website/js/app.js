document.addEventListener("DOMContentLoaded", function() {
  Carousel();
  ShowMore();
  Accordion();
  Zoom();
  Changemode();
});